package edu.ccrm.service;

import edu.ccrm.domain.Course;
import edu.ccrm.io.FileUtilityService;
import java.util.ArrayList;
import java.util.List;

public class CourseService {
    private List<Course> courses;
    private static final String DATA_FILE = "courses.dat";
    private FileUtilityService fileUtilityService = new FileUtilityService();

    public CourseService() {
        loadCourses();
    }

    @SuppressWarnings("unchecked")
    private void loadCourses() {
        Object data = fileUtilityService.loadData(DATA_FILE);
        if (data instanceof List) {
            this.courses = (List<Course>) data;
        } else {
            this.courses = new ArrayList<>();
            // Initialize with dummy data if file doesn't exist
            courses.add(new Course.Builder().code("CS101").title("Intro to Programming").credits(4).department("Computer Science").build());
            courses.add(new Course.Builder().code("MATH201").title("Calculus I").credits(4).department("Mathematics").build());
            courses.add(new Course.Builder().code("PHYS101").title("General Physics I").credits(3).department("Physics").build());
        }
    }

    public void saveCourses() {
        fileUtilityService.saveData(DATA_FILE, this.courses);
    }

    public List<Course> getAllCourses() {
        return new ArrayList<>(courses);
    }

    public List<Course> getCoursesByDepartment(String department) {
        return courses.stream()
                .filter(c -> department.equals(c.getDepartment()))
                .collect(java.util.stream.Collectors.toList());
    }
    
    public void manageCourses() {
        // This method can be used for CLI-based management if needed
        System.out.println("Managing courses...");
        courses.forEach(System.out::println);
    }
}