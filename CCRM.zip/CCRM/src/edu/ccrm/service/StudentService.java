package edu.ccrm.service;

import edu.ccrm.domain.Student;
import edu.ccrm.io.FileUtilityService;
import java.util.ArrayList;
import java.util.List;

public class StudentService {
    private List<Student> students;
    private static final String DATA_FILE = "students.dat";
    private FileUtilityService fileUtilityService = new FileUtilityService();

    public StudentService() {
        loadStudents();
    }

    @SuppressWarnings("unchecked")
    private void loadStudents() {
        Object data = fileUtilityService.loadData(DATA_FILE);
        if (data instanceof List) {
            this.students = (List<Student>) data;
        } else {
            this.students = new ArrayList<>();
            // Initialize with dummy data if file doesn't exist
            students.add(new Student("001", "Alice Johnson", "alice@example.com", "REG2023001"));
            students.add(new Student("002", "Bob Williams", "bob@example.com", "REG2023002"));
        }
    }

    public void saveStudents() {
        fileUtilityService.saveData(DATA_FILE, this.students);
    }

    public List<Student> getAllStudents() {
        return new ArrayList<>(students);
    }

    public void addStudent(Student student) {
        students.add(student);
        saveStudents();
    }
    
    public void manageStudents() {
        // This method can be used for CLI-based management if needed
        System.out.println("Managing students...");
        students.forEach(Student::printProfile);
    }
}