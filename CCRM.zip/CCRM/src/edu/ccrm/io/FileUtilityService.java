package edu.ccrm.io;

import edu.ccrm.config.AppConfig;
import java.io.*;
import java.nio.file.*;

public class FileUtilityService {
    private final AppConfig config = AppConfig.getInstance();
    private final Path dataPath;

    public FileUtilityService() {
        this.dataPath = Paths.get(config.getDataFolderPath());
        try {
            ensureDirectory(this.dataPath);
        } catch (IOException e) {
            System.err.println("Failed to create data directory: " + e.getMessage());
        }
    }

    public void saveData(String fileName, Object data) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(dataPath.resolve(fileName).toFile()))) {
            oos.writeObject(data);
            System.out.println("Data saved to " + fileName);
        } catch (IOException e) {
            System.err.println("Error saving data to " + fileName + ": " + e.getMessage());
        }
    }

    public Object loadData(String fileName) {
        File file = dataPath.resolve(fileName).toFile();
        if (!file.exists()) {
            return null;
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading data from " + fileName + ": " + e.getMessage());
            return null;
        }
    }

    private void ensureDirectory(Path dir) throws IOException {
        if (!Files.exists(dir)) {
            Files.createDirectories(dir);
            System.out.println("Created directory: " + dir);
        }
    }
}