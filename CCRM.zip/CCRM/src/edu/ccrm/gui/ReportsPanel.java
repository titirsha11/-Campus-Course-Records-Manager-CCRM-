package edu.ccrm.gui;

import java.awt.*;
import javax.swing.*;

public class ReportsPanel extends JPanel {
    public ReportsPanel() {
        setLayout(new BorderLayout());
        JLabel label = new JLabel("Reports", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 18));
        add(label, BorderLayout.NORTH);
        // Add reporting logic here
    }
}
