package edu.ccrm.gui;

import edu.ccrm.domain.Course;
import edu.ccrm.service.CourseService;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class CoursePanel extends JPanel {
    private CourseService courseService;
    private JTable courseTable;
    private DefaultTableModel tableModel;
    private String department;

    public CoursePanel(String department) {
        this.department = department;
        this.courseService = new CourseService();
        setLayout(new BorderLayout());
        initUI();
        loadCourseData();
    }

    private void initUI() {
        // Table Model
        String[] columnNames = {"Code", "Title", "Credits", "Instructor"};
        tableModel = new DefaultTableModel(columnNames, 0);
        courseTable = new JTable(tableModel);

        // Add the table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(courseTable);
        add(scrollPane, BorderLayout.CENTER);

        // Add a title
        JLabel titleLabel = new JLabel(department + " Courses", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        add(titleLabel, BorderLayout.NORTH);
    }

    private void loadCourseData() {
        List<Course> courses = courseService.getCoursesByDepartment(department);
        for (Course c : courses) {
            Object[] row = {c.getCode(), c.getTitle(), c.getCredits(), c.getInstructor()};
            tableModel.addRow(row);
        }
    }
}
