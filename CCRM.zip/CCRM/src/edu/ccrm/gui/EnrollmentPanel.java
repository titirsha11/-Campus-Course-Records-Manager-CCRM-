package edu.ccrm.gui;

import java.awt.*;
import javax.swing.*;

public class EnrollmentPanel extends JPanel {
    public EnrollmentPanel() {
        setLayout(new BorderLayout());
        JLabel label = new JLabel("Enrollment Management", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 18));
        add(label, BorderLayout.NORTH);
        // Add enrollment form and logic here
    }
}
