package edu.ccrm.gui;

import edu.ccrm.domain.Student;
import edu.ccrm.service.StudentService;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class StudentPanel extends JPanel {
    private StudentService studentService;
    private JTable studentTable;
    private DefaultTableModel tableModel;

    public StudentPanel() {
        this.studentService = new StudentService();
        setLayout(new BorderLayout());
        initUI();
        loadStudentData();
    }

    private void initUI() {
        // Table Model
        String[] columnNames = {"ID", "Name", "Email", "Registration ID"};
        tableModel = new DefaultTableModel(columnNames, 0);
        studentTable = new JTable(tableModel);

        // Add the table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(studentTable);
        add(scrollPane, BorderLayout.CENTER);

        // Add a title
        JLabel titleLabel = new JLabel("Student Management", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        add(titleLabel, BorderLayout.NORTH);
    }

    private void loadStudentData() {
        List<Student> students = studentService.getAllStudents();
        for (Student s : students) {
            Object[] row = {s.getId(), s.getName(), s.getEmail(), s.getRegistrationId()};
            tableModel.addRow(row);
        }
    }
}
