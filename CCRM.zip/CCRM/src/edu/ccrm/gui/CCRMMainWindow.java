package edu.ccrm.gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import javax.swing.*;

public class CCRMMainWindow extends JFrame {
    private JPanel mainPanel;

    public CCRMMainWindow() {
        setTitle("Campus Course Records Manager (CCRM)");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
    }

    private void initUI() {
        // Main Panel
        mainPanel = new JPanel(new BorderLayout());
        JLabel welcomeLabel = new JLabel("Welcome to CCRM!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        mainPanel.add(welcomeLabel, BorderLayout.CENTER);
        
        // Create actions
        Action manageStudentsAction = new AbstractAction("Manage Students", UIManager.getIcon("FileView.directoryIcon")) {
            @Override
            public void actionPerformed(ActionEvent e) {
                showStudentPanel();
            }
        };

        Action exitAction = new AbstractAction("Exit", UIManager.getIcon("InternalFrame.closeIcon")) {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        };

        // Menu Bar
        JMenuBar menuBar = new JMenuBar();
        
        // File Menu
        JMenu fileMenu = new JMenu("File");
        fileMenu.add(new JMenuItem(exitAction));
        
        // Manage Menu
        JMenu manageMenu = new JMenu("Manage");
        manageMenu.add(new JMenuItem(manageStudentsAction));
        
        // Courses Sub-Menu
        JMenu coursesMenu = new JMenu("Courses");
        
        String[] departments = {"Computer Science", "Mathematics", "Physics", "Chemistry", "Humanities", "Business"};
        for (String department : departments) {
            Action courseAction = new AbstractAction(department) {
                @Override
                public void actionPerformed(ActionEvent e) {
                    showCoursePanel(department);
                }
            };
            coursesMenu.add(new JMenuItem(courseAction));
        }

        manageMenu.add(coursesMenu);

        // Other Menus
        JMenu enrollmentMenu = new JMenu("Enrollment");
        JMenuItem enrollmentItem = new JMenuItem("Manage Enrollment", UIManager.getIcon("FileView.fileIcon"));
        enrollmentItem.addActionListener(e -> showEnrollmentPanel());
        enrollmentMenu.add(enrollmentItem);

        JMenu reportsMenu = new JMenu("Reports");
        JMenuItem reportsItem = new JMenuItem("View Reports", UIManager.getIcon("FileView.hardDriveIcon"));
        reportsItem.addActionListener(e -> showReportsPanel());
        reportsMenu.add(reportsItem);

        JMenu youtubeMenu = new JMenu("YouTube");
        JMenuItem youtubeItem = new JMenuItem("Channel Links", UIManager.getIcon("FileView.computerIcon"));
        youtubeItem.addActionListener(e -> showYouTubePanel());
        youtubeMenu.add(youtubeItem);

        menuBar.add(fileMenu);
        menuBar.add(manageMenu);
        menuBar.add(coursesMenu);
        menuBar.add(enrollmentMenu);
        menuBar.add(reportsMenu);
        menuBar.add(youtubeMenu);
        
        setJMenuBar(menuBar);

        // Toolbar
        JToolBar toolBar = new JToolBar();
        toolBar.add(new JButton(manageStudentsAction));
        toolBar.addSeparator();
        toolBar.add(new JButton(exitAction));
        
        mainPanel.add(toolBar, BorderLayout.NORTH);
        setContentPane(mainPanel);
    }

    private void showStudentPanel() {
        mainPanel.removeAll();
        mainPanel.add(new StudentPanel(), BorderLayout.CENTER);
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    private void showCoursePanel(String department) {
        mainPanel.removeAll();
        mainPanel.add(new CoursePanel(department), BorderLayout.CENTER);
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    private void showEnrollmentPanel() {
        mainPanel.removeAll();
        mainPanel.add(new EnrollmentPanel(), BorderLayout.CENTER);
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    private void showReportsPanel() {
        mainPanel.removeAll();
        mainPanel.add(new ReportsPanel(), BorderLayout.CENTER);
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    private void showYouTubePanel() {
        mainPanel.removeAll();
        mainPanel.add(new YouTubePanel(), BorderLayout.CENTER);
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new CCRMMainWindow().setVisible(true);
        });
    }
}
