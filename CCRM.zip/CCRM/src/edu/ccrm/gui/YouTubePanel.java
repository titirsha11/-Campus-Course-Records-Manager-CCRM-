package edu.ccrm.gui;

import java.awt.*;
import javax.swing.*;

public class YouTubePanel extends JPanel {
    public YouTubePanel() {
        setLayout(new BorderLayout());
        JLabel label = new JLabel("Recommended YouTube Channels", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 18));
        add(label, BorderLayout.NORTH);
        JTextArea links = new JTextArea(
            "- Java Brains: https://www.youtube.com/user/koushks\n" +
            "- freeCodeCamp.org: https://www.youtube.com/c/Freecodecamp\n" +
            "- The Net Ninja: https://www.youtube.com/c/TheNetNinja\n" +
            "- Programming with Mosh: https://www.youtube.com/c/programmingwithmosh\n"
        );
        links.setEditable(false);
        add(new JScrollPane(links), BorderLayout.CENTER);
    }
}
